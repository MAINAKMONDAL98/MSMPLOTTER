//https://github.com/MAINAKMONDAL98
#ifndef MSMPLOTTER_h
#define MSMPLOTTER_h
#include "Arduino.h"
class MSMPLOTTER{
	public:
		void msmplotter(uint16_t arr[],uint16_t p);
	};
#endif;
