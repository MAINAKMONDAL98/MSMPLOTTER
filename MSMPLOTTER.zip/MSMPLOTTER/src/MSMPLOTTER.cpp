//https://github.com/MAINAKMONDAL98
#include "Arduino.h"
#include"MSMPLOTTER.h"
void MSMPLOTTER::msmplotter(uint16_t arr[],uint16_t p){
	Serial.println("developed by MAINAKMONDAL98");
	Serial.println("MSMPLOTTER");
  uint16_t storage=0;
    for(uint8_t a1=0;a1<p-1;a1++){
    if(abs(arr[a1]-arr[a1+1])>1){
      if(arr[a1]>arr[a1+1]){
        storage=storage+(abs(arr[a1]-arr[a1+1]));
      }
      else{
        storage=storage+(abs(arr[a1]-arr[a1+1]));
      }
    }
    else{
        storage=storage+1;
    }
  }
  storage=storage+1;
  uint16_t array_graph[storage];
  uint8_t b=0;
  for(uint8_t a1=0;a1<p-1;a1++){
    if(abs(arr[a1]-arr[a1+1])>1){
      if(arr[a1]>arr[a1+1]){
        for(int8_t b1=0;b1<(abs(arr[a1]-arr[a1+1]));b1++){
          array_graph[b+b1]=arr[a1]-b1;
        }
        b=b+(abs(arr[a1]-arr[a1+1]));
      }
      else{
        for(int8_t b1=0;b1<(abs(arr[a1]-arr[a1+1]));b1++){
          array_graph[b+b1]=arr[a1]+b1;
        }
        b=b+(abs(arr[a1]-arr[a1+1]));
      }
    }
    else{
    array_graph[b]=arr[a1];
    b=b+1;
  }
  }
  array_graph[b]=arr[p-1];
 uint16_t a2=0,a3=1000;
  for(int8_t a1=0;a1<b+1;a1++){
    if(array_graph[a1]<a3){
      a3=array_graph[a1];
    }
    else if(array_graph[a1]>a2){
      
      a2=array_graph[a1];
    }
  }
  for(int8_t a4=a2;a4>=0;a4--){
    for(uint8_t a1=0;a1<b+1;a1++){
      if(a4==array_graph[a1]){
        Serial.print("#");
      }
      else{
        Serial.print("-");
      }
    }
    for(int a5=0;a5<165-b;a5++){
      Serial.print("-");
    }
    Serial.println("-");
  }
}
